import 'package:get/get.dart';

import 'package:dreamcast/view/beforeLogin/login/login_controller.dart';

class LoginBinding extends Bindings {
  @override
  void dependencies() {
    Get.put<LoginController>(LoginController());

  }
}