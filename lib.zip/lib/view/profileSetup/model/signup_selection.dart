import 'package:get/get.dart';
class MyVisitor{
  var title="".obs;
  var id="";
  var selected=false.obs;
  MyVisitor.create({required this.title,required this.id,required this.selected});
}
class MyAreaInterest{
  var title="".obs;
  var id="";
  var selected=false.obs;
  MyAreaInterest.create({required this.title,required this.id,required this.selected});
}