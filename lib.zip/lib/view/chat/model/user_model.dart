
class UserModel {
  String? userId;
  String? fullName;
  String? shortName;
  String? avtar;
  String? roomId;
  String? iam;
  int? chatRequestStatus;
  UserModel({this.userId,this.fullName,this.shortName,this.avtar,this.roomId,this.iam,this.chatRequestStatus});
}
