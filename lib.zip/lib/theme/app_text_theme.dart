import 'package:flutter/material.dart';

import 'app_colors.dart';

const TextStyle cardTextStyle = TextStyle(
    color: white,
    fontSize: 16,
    fontWeight: FontWeight.bold
);